const firebaseConfig = {
	apiKey: 'AIzaSyDJAVJ4NsTVG6i9hKowGnNOmljP8KcFwxk',
	authDomain: 'test-b68c5.firebaseapp.com',
	databaseURL: 'https://test-b68c5.firebaseio.com',
	projectId: 'test-b68c5',
	storageBucket: 'test-b68c5.appspot.com',
	messagingSenderId: '553694227738',
	appId: '1:553694227738:web:e13d6440a3e8bcd3d7d0a3',
	measurementId: 'G-V424Q2ZBRC'
};

export default firebaseConfig;
