enum Schedule{
    MORNING, LATE
}