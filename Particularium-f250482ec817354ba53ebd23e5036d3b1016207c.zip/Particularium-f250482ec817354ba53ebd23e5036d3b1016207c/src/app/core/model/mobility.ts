enum Mobility {
    AT_HOME, OWN_LOCAL
}