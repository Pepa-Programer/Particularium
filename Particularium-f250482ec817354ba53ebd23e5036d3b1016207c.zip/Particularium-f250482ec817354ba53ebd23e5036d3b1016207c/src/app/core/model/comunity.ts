enum Comunity {
    IGNORE, GROUP, INDIVIDUAL
}